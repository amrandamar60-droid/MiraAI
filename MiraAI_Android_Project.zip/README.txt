Mira AI Studio Android project

To build an APK:
1. Install Android Studio on a computer.
2. Open this project folder.
3. Allow Gradle sync.
4. Select Build > Build APK(s).
5. Find APK in app/build/outputs/apk/debug/.

This is an Android WebView wrapper around the current prototype. AI generation APIs are not connected yet.
