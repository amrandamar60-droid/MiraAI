Mira AI - Android WebView Project
=================================

هذا مشروع أندرويد يفتح موقع:
https://mira-imagine-e11e.whacka.app

ملاحظة مهمة:
هذا ZIP يحتوي على ملفات المشروع المصدرية، وليس APK جاهزًا. لا تتوفر بيئة Android SDK هنا لبناء APK مباشرة.

طريقة البناء:
1) ارفع المشروع إلى GitHub.
2) افتحه عبر Android Studio على كمبيوتر، أو استخدم خدمة بناء Android متوافقة مع Gradle.
3) نفّذ assembleDebug.
4) ملف APK الناتج يكون عادة:
   app/build/outputs/apk/debug/app-debug.apk

يمكن استخدام GitHub Actions workflow المرفق لتجربة بناء APK تلقائيًا عند رفع المشروع إلى مستودع GitHub.
